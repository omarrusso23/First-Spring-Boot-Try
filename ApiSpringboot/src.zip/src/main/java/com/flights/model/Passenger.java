package com.flights.model;
import java.util.Objects;

import javax.persistence.*;

@Entity
@Table(name = "passenger")
public class Passenger {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(unique = true, nullable = false)
	private int idkey;


	private String firstName;
	private String lastName;
	private String id;
	private String nation;
	private int age;
	private int hasLuggage;

	
	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getNation() {
		return nation;
	}

	public void setNation(String nation) {
		this.nation = nation;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public int getHasLuggage() {
		return hasLuggage;
	}

	public void setHasLuggage(int hasLuggage) {
		this.hasLuggage = hasLuggage;
	}

	public Passenger() {
		
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(id);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Passenger other = (Passenger) obj;
		return Objects.equals(id, other.id);
	}



	@Override
	public String toString() {
		return "Passenger [idkey=" + idkey + ", firstName=" + firstName + ", lastName=" + lastName + ", id=" + id
				+ ", nation=" + nation + ", age=" + age + ", hasLuggage=" + hasLuggage + "]";
	}



	public enum Nationality {
		Austria, Belgium, Bulgaria, Cyprus, CzechRepublic, Denmark, Estonia, Finland, France, Germany, Greece, Hungary,
		Ireland, Italy, Latvia, Lithuania, Luxembourg, Malta, Netherlands, Poland, Portugal, Romania, Slovakia,
		Slovenia, Spain, Sweden, UnitedKingdom
	}

}
