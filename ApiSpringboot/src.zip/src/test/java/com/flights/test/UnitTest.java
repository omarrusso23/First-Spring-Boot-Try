package com.flights.test;

import static org.junit.Assert.*;

import org.junit.jupiter.api.Test;

import com.flights.model.Passenger;

class UnitTest {

	@Test
	 public void Add_ValidPassenger_ReturnPassenger()
    {
	Passenger nPassenger = new Passenger();
	nPassenger.setAge(20);
	nPassenger.setFirstName("Perez");
	nPassenger.setLastName("Juan");
	nPassenger.setId("22900811");
	nPassenger.setNation("Spain");
	nPassenger.setHasLuggage(0);
	
	
	//Assert.ass
    }
}
